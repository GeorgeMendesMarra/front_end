package com.example.portfolio;

import jakarta.annotation.PostConstruct;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Named;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * Managed Bean CDI (@Named/@ApplicationScoped) responsavel por fornecer os
 * dados exibidos na pagina inicial do portfolio: link do blog, disciplinas
 * ministradas e repositorios em destaque no GitHub.
 *
 * Escopo ApplicationScoped: os dados sao carregados uma unica vez (no
 * metodo anotado com @PostConstruct) e compartilhados entre todos os
 * usuarios da aplicacao.
 */
@Named("portfolioBean")
@ApplicationScoped
public class PortfolioBean implements Serializable {

    private static final long serialVersionUID = 1L;

    private static final String BLOG_URL = "https://georgemendesmarra.blogspot.com/";
    private static final String GITHUB_PROFILE_URL = "https://github.com/GeorgeMendesMarra";

    private List<BlogTopic> blogTopics;
    private List<GithubRepo> githubRepos;

    @PostConstruct
    public void init() {

        // Disciplinas/paginas listadas no blog (georgemendesmarra.blogspot.com)
        blogTopics = new ArrayList<>();
        blogTopics.add(new BlogTopic("Programação Orientada a Objetos - Java", "https://georgemendesmarra.blogspot.com/p/java.html"));
        blogTopics.add(new BlogTopic("Estrutura de Dados I", "https://georgemendesmarra.blogspot.com/p/estrutura-de-dados-i.html"));
        blogTopics.add(new BlogTopic("Sistemas Operacionais", "https://georgemendesmarra.blogspot.com/p/sistemas-operacionais.html"));
        blogTopics.add(new BlogTopic("Projeto de Banco de Dados", "https://georgemendesmarra.blogspot.com/p/projeto-de-banco-de-dados.html"));
        blogTopics.add(new BlogTopic("Linguagens Formais e Autômatos Finitos", "https://georgemendesmarra.blogspot.com/p/linguagens-formais-e-automatos-finitos.html"));
        blogTopics.add(new BlogTopic("Pesquisa Operacional e Otimização", "https://georgemendesmarra.blogspot.com/p/pesquisa-operacional-e-otimizacao.html"));
        blogTopics.add(new BlogTopic("Lógica Computacional II", "https://georgemendesmarra.blogspot.com/p/logica-computacional-ii.html"));
        blogTopics.add(new BlogTopic("Engenharia de Software", "https://georgemendesmarra.blogspot.com/p/engenharia-de-software.html"));
        blogTopics.add(new BlogTopic("Front-End", "https://georgemendesmarra.blogspot.com/p/front-end.html"));
        blogTopics.add(new BlogTopic("Back-End", "https://georgemendesmarra.blogspot.com/p/back-end.html"));
        blogTopics.add(new BlogTopic("Python", "https://georgemendesmarra.blogspot.com/p/python.html"));
        blogTopics.add(new BlogTopic("GNU/Linux", "https://georgemendesmarra.blogspot.com/p/gnulinux.html"));

        // Repositorios em destaque no GitHub
        githubRepos = new ArrayList<>();
        githubRepos.add(new GithubRepo(
                "GeorgeMendesMarra",
                "Repositório público principal do Professor George Mendes Marra",
                "https://github.com/GeorgeMendesMarra",
                "Perfil"
        ));
        githubRepos.add(new GithubRepo(
                "pos_graduacao",
                "Repositório público das disciplinas de pós-graduação ministradas",
                "https://github.com/GeorgeMendesMarra/pos_graduacao",
                "Diversos"
        ));
        githubRepos.add(new GithubRepo(
                "front_end",
                "Repositório público sobre a disciplina de Front-End",
                "https://github.com/GeorgeMendesMarra/front_end",
                "HTML"
        ));
    }

    public String getBlogUrl() {
        return BLOG_URL;
    }

    public String getGithubProfileUrl() {
        return GITHUB_PROFILE_URL;
    }

    public List<BlogTopic> getBlogTopics() {
        return blogTopics;
    }

    public List<GithubRepo> getGithubRepos() {
        return githubRepos;
    }
}
