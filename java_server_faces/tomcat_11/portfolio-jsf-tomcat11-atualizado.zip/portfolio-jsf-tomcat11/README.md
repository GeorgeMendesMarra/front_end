# Portfolio JSF — George Mendes Marra (Debian 13 + Tomcat 11)

Página inicial em **Jakarta Faces (JSF 4.0)** que reúne:

- Link e destaques do blog pessoal: https://georgemendesmarra.blogspot.com/
- Repositórios do GitHub:
  - https://github.com/GeorgeMendesMarra
  - https://github.com/GeorgeMendesMarra/pos_graduacao
  - https://github.com/GeorgeMendesMarra/front_end

Projeto construído para **Tomcat 11** (Jakarta EE 11 / Servlet 6.1), que usa
o namespace `jakarta.*` — diferente das versões anteriores (Tomcat 9 e
antes), que usavam `javax.*`.

## Por que este projeto inclui CDI (Weld)?

A partir do **Jakarta Faces 3.0** (adotado a partir do Tomcat 10), a
anotação clássica `javax.faces.bean.ManagedBean` foi **removida** da
especificação. Managed beans agora **precisam** usar CDI (`@Named` +
`@ApplicationScoped` de `jakarta.enterprise.context` / `jakarta.inject`).

Como o Tomcat é um servlet container puro (sem CDI nativo, ao contrário de
WildFly/Payara), este projeto empacota o **Weld** (implementação de
referência do CDI) diretamente dentro do WAR, através do artefato
`weld-servlet-shaded`. Isso significa que **nada precisa ser instalado no
Tomcat** além do WAR gerado — tudo já vem embutido.

## Estrutura do projeto

```
portfolio-jsf-tomcat11/
├── pom.xml
├── src/main/java/com/example/portfolio/
│   ├── PortfolioBean.java   # managed bean CDI com os dados do blog e GitHub
│   ├── BlogTopic.java       # modelo: disciplina/topico do blog
│   └── GithubRepo.java      # modelo: repositorio do GitHub
└── src/main/webapp/
    ├── index.xhtml               # pagina unica do portfolio
    ├── resources/css/style.css   # visual (cards, hero, tema escuro)
    └── WEB-INF/
        ├── web.xml           # FacesServlet + listener do Weld
        ├── faces-config.xml  # configuracao do Jakarta Faces
        └── beans.xml         # habilita a descoberta de beans CDI
```

## Requisitos no Debian 13

- **Java 17+** (JDK), recomendado para Tomcat 11:
  ```bash
  sudo apt update
  sudo apt install openjdk-17-jdk maven
  ```
- **Apache Tomcat 11** instalado. No Debian 13, o pacote `tomcat11` pode
  não estar nos repositórios padrão ainda — o caminho mais confiável é
  baixar o binário direto do site oficial:
  ```bash
  cd /opt
  sudo wget https://dlcdn.apache.org/tomcat/tomcat-11/v11.0.5/bin/apache-tomcat-11.0.5.tar.gz
  sudo tar xzf apache-tomcat-11.0.5.tar.gz
  sudo mv apache-tomcat-11.0.5 tomcat11
  sudo chmod +x /opt/tomcat11/bin/*.sh
  ```
  (verifique em https://tomcat.apache.org/download-11.cgi qual é a versão
  mais recente disponível).

## Como gerar o WAR

Na raiz do projeto:

```bash
mvn clean package
```

Isso gera `target/portfolio-jsf.war`, já contendo o Jakarta Faces (Mojarra)
e o CDI (Weld) embutidos.

## Como fazer o deploy no Tomcat 11

**Opção 1 — copiar o WAR (mais simples):**

```bash
sudo cp target/portfolio-jsf.war /opt/tomcat11/webapps/
sudo /opt/tomcat11/bin/startup.sh
```

O Tomcat detecta o WAR e faz o deploy automaticamente
(`webapps/portfolio-jsf/`). Depois acesse:

```
http://localhost:8080/portfolio-jsf/
```

Para parar o Tomcat:
```bash
sudo /opt/tomcat11/bin/shutdown.sh
```

**Opção 2 — rodando como serviço systemd:**

Crie `/etc/systemd/system/tomcat11.service` apontando `CATALINA_HOME` para
`/opt/tomcat11`, depois:

```bash
sudo systemctl daemon-reload
sudo systemctl enable --now tomcat11
sudo cp target/portfolio-jsf.war /opt/tomcat11/webapps/
```

## Personalizando os dados

Todos os textos, links e cards vêm do managed bean `PortfolioBean.java`
(método `init()`, anotado com `@PostConstruct`). Para adicionar mais
repositórios ou disciplinas do blog, basta incluir novos objetos
`GithubRepo` ou `BlogTopic` nas listas correspondentes — o `index.xhtml`
já usa `ui:repeat`, então novos itens aparecem automaticamente sem
precisar mexer no HTML.

## Personalizando o visual

Cores, espaçamento e o efeito de destaque dos cards estão em
`resources/css/style.css`. A cor de destaque principal (`#ff8a3d`, laranja)
é usada nos botões e ao passar o mouse nos cards — troque essa cor em
todas as ocorrências para mudar o tema.
