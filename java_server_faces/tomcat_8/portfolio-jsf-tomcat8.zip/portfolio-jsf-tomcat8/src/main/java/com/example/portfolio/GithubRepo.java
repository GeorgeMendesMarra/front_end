package com.example.portfolio;

import java.io.Serializable;

/**
 * Representa um repositorio do GitHub exibido na pagina inicial.
 */
public class GithubRepo implements Serializable {

    private static final long serialVersionUID = 1L;

    private String name;
    private String description;
    private String url;
    private String language;

    public GithubRepo(String name, String description, String url, String language) {
        this.name = name;
        this.description = description;
        this.url = url;
        this.language = language;
    }

    public String getName() {
        return name;
    }

    public String getDescription() {
        return description;
    }

    public String getUrl() {
        return url;
    }

    public String getLanguage() {
        return language;
    }
}
