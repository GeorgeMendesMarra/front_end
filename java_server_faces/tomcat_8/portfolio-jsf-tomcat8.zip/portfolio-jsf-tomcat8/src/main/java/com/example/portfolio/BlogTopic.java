package com.example.portfolio;

import java.io.Serializable;

/**
 * Representa uma disciplina/topico listado no blog pessoal, com o titulo
 * exibido e o link direto para a pagina correspondente no Blogger.
 */
public class BlogTopic implements Serializable {

    private static final long serialVersionUID = 1L;

    private String title;
    private String url;

    public BlogTopic(String title, String url) {
        this.title = title;
        this.url = url;
    }

    public String getTitle() {
        return title;
    }

    public String getUrl() {
        return url;
    }
}
