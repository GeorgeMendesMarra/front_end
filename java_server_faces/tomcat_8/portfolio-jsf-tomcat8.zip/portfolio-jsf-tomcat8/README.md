# Portfolio JSF — George Mendes Marra (Tomcat 8)

Página inicial em **JSF 2.3 (Mojarra, namespace `javax.*`)** que reúne:

- Link e destaques do blog pessoal: https://georgemendesmarra.blogspot.com/
- Repositórios do GitHub:
  - https://github.com/GeorgeMendesMarra
  - https://github.com/GeorgeMendesMarra/pos_graduacao
  - https://github.com/GeorgeMendesMarra/front_end
  - https://github.com/GeorgeMendesMarra/back_end

Projeto construído para **Tomcat 8** (Servlet 3.1 / Java EE 8), que usa o
namespace `javax.*` — diferente do Tomcat 10+/11, que usa `jakarta.*`.
Esta é a versão irmã do projeto original feito para Tomcat 11
(`portfolio-jsf-tomcat11`), migrada para o namespace antigo.

## Por que este projeto inclui CDI (Weld)?

Managed beans usam CDI (`@Named` + `@ApplicationScoped` de
`javax.enterprise.context` / `javax.inject`) em vez da antiga anotação
`javax.faces.bean.ManagedBean`. O Tomcat é um servlet container puro (sem
CDI nativo), então o Weld (`weld-servlet-shaded`, versão 3.1.x — compatível
com CDI 2.0/Java EE 8) vai empacotado dentro do próprio WAR.

## Compilando

Requer JDK 8+ e Maven instalados (`mvn -version` para conferir):

```bash
mvn clean package
```

O arquivo gerado fica em `target/portfolio-jsf.war`.

## Publicando no Tomcat 8

Copie o `.war` para a pasta `webapps/` do Tomcat. Para publicar na raiz do
domínio, renomeie para `ROOT.war` (removendo antes o `ROOT` padrão que já
existe em `webapps/`).

## Compatibilidade de versão do Java

Este projeto está configurado para compilar com **Java 8**
(`maven.compiler.source/target = 8`), o alvo mais seguro para Tomcat 8. Se
o seu servidor roda uma JVM mais recente (11+), o projeto também compila
normalmente nessa configuração — não é necessário mudar nada.
